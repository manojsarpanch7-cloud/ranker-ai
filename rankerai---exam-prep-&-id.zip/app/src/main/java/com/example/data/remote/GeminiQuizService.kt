package com.example.data.remote

import com.example.BuildConfig
import com.example.data.model.QuizQuestion
import com.example.data.model.TargetExam
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiQuizService {

    private val apiKey: String = BuildConfig.GEMINI_API_KEY.ifBlank { "" }
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun generateQuizForTopic(
        targetExam: TargetExam,
        topic: String
    ): List<QuizQuestion> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext emptyList()
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey"

            val prompt = """
                Generate a 5-question multiple choice quiz for a student preparing for ${targetExam.title} (${targetExam.name}).
                The topic is "$topic".
                Include Previous Year Question (PYQ) pattern questions.
                Return strictly a raw JSON array of 5 objects without markdown formatting or code blocks:
                [
                  {
                    "questionText": "Question text here",
                    "options": ["Option A", "Option B", "Option C", "Option D"],
                    "correctAnswerIndex": 0,
                    "explanation": "Detailed step-by-step solution"
                  }
                ]
            """.trimIndent()

            val jsonBody = JSONObject().apply {
                put("contents", JSONArray().put(
                    JSONObject().apply {
                        put("parts", JSONArray().put(
                            JSONObject().apply {
                                put("text", prompt)
                            }
                        ))
                    }
                ))
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody(mediaType))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext emptyList()

                val responseBody = response.body?.string() ?: return@withContext emptyList()
                val jsonResponse = JSONObject(responseBody)
                val candidates = jsonResponse.optJSONArray("candidates") ?: return@withContext emptyList()
                if (candidates.length() == 0) return@withContext emptyList()

                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.getJSONObject("content")
                val parts = content.getJSONArray("parts")
                val rawText = parts.getJSONObject(0).getString("text")

                val cleanJsonText = rawText.replace("```json", "").replace("```", "").trim()
                val jsonArray = JSONArray(cleanJsonText)
                val questionsList = mutableListOf<QuizQuestion>()

                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val questionText = obj.getString("questionText")
                    val optionsArray = obj.getJSONArray("options")
                    val options = mutableListOf<String>()
                    for (j in 0 until optionsArray.length()) {
                        options.add(optionsArray.getString(j))
                    }
                    val correctAnswerIndex = obj.getInt("correctAnswerIndex")
                    val explanation = obj.getString("explanation")

                    questionsList.add(
                        QuizQuestion(
                            id = "gemini_$i",
                            questionText = questionText,
                            options = options,
                            correctAnswerIndex = correctAnswerIndex,
                            explanation = explanation
                        )
                    )
                }

                return@withContext questionsList
            }
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }
}
