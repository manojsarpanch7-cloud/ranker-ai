package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TargetExam(
    val code: String,
    val title: String,
    val subtitle: String,
    val defaultCollege: String,
    val defaultPickupLine: String,
    val bgImageAssetName: String,
    val iconEmoji: String,
    val subjects: List<String>
) {
    NEET(
        code = "NEET",
        title = "NEET UG",
        subtitle = "Medical Entrance (AIIMS / JIPMER)",
        defaultCollege = "AIIMS New Delhi",
        defaultPickupLine = "Future Doctor holding Stethoscope 🩺",
        bgImageAssetName = "aiims_delhi_bg_1786202788147.jpg",
        iconEmoji = "🩺",
        subjects = listOf("Biology (Botany & Zoology)", "Physics", "Chemistry")
    ),
    JEE(
        code = "JEE",
        title = "JEE Mains & Advanced",
        subtitle = "Engineering Entrance (IITs / NITs)",
        defaultCollege = "IIT Bombay",
        defaultPickupLine = "Future IITian engineering the future 🚀",
        bgImageAssetName = "iit_bombay_bg_1786202800673.jpg",
        iconEmoji = "⚡",
        subjects = listOf("Physics", "Chemistry", "Mathematics")
    ),
    UPSC(
        code = "UPSC",
        title = "UPSC Civil Services",
        subtitle = "IAS / IPS / IFS Officers Exam",
        defaultCollege = "LBSNAA Mussoorie",
        defaultPickupLine = "Future IAS Officer serving the Nation 🇮🇳",
        bgImageAssetName = "lbsnaa_upsc_bg_1786202813806.jpg",
        iconEmoji = "🏛️",
        subjects = listOf("Indian Polity & Governance", "Modern History", "Geography & Environment", "General Studies")
    ),
    CA(
        code = "CA",
        title = "CA Foundation / Inter",
        subtitle = "Chartered Accountancy",
        defaultCollege = "ICAI New Delhi",
        defaultPickupLine = "Future CA mastering finance & audit 💼",
        bgImageAssetName = "icai_ca_bg_1786202827601.jpg",
        iconEmoji = "📈",
        subjects = listOf("Accounting & Financial Reporting", "Corporate Laws", "Costing & Analytics", "Taxation")
    ),
    BOARDS(
        code = "BOARDS",
        title = "Class 10th / 12th Boards",
        subtitle = "CBSE / State Board 95%+ Target",
        defaultCollege = "Delhi University / Top College",
        defaultPickupLine = "Board Topper achieving excellence 🎓",
        bgImageAssetName = "aiims_delhi_bg_1786202788147.jpg",
        iconEmoji = "📚",
        subjects = listOf("Physics / Science", "Chemistry", "Mathematics", "English / Humanities")
    );

    val bgTitle: String get() = defaultCollege
}

data class UserProfile(
    val name: String = "Kartiken",
    val targetExam: TargetExam = TargetExam.NEET,
    val targetCollege: String = "AIIMS New Delhi",
    val pickupLine: String = "Future Doctor holding Stethoscope 🩺",
    val photoUri: String? = null,
    val isPro: Boolean = false,
    val studentIdNumber: String = "RANKER-2026-NEET089",
    val totalStudyMinutes: Int = 1420,
    val currentStreak: Int = 5
)

@Entity(tableName = "study_tasks")
data class StudyTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subject: String,
    val examCode: String,
    val isCompleted: Boolean = false,
    val dateString: String = "Today"
)

@Entity(tableName = "study_logs")
data class StudyLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: String,
    val minutesLogged: Int,
    val dateTimestamp: Long = System.currentTimeMillis()
)

data class PyqItem(
    val id: String,
    val year: String,
    val questionText: String,
    val options: List<String>,
    val correctAnswerIndex: Int,
    val stepByStepSolution: String
)

data class StudyNote(
    val id: String,
    val examCode: String = "NEET",
    val subject: String,
    val chapter: String,
    val title: String,
    val contentSummary: String,
    val keyPoints: List<String> = emptyList(),
    val highYieldFormulas: List<String> = emptyList(),
    val isPyq: Boolean = true,
    val pyqs: List<PyqItem> = emptyList()
)

data class QuizQuestion(
    val id: String,
    val questionText: String,
    val options: List<String>,
    val correctAnswerIndex: Int,
    val explanation: String
)
