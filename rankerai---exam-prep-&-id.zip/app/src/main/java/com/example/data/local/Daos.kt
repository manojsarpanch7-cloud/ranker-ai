package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.StudyLog
import com.example.data.model.StudyTask
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyTaskDao {
    @Query("SELECT * FROM study_tasks ORDER BY id DESC")
    fun getAllTasks(): Flow<List<StudyTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: StudyTask)

    @Update
    suspend fun updateTask(task: StudyTask)

    @Delete
    suspend fun deleteTask(task: StudyTask)

    @Query("SELECT COUNT(*) FROM study_tasks")
    suspend fun getTaskCount(): Int
}

@Dao
interface StudyLogDao {
    @Query("SELECT * FROM study_logs ORDER BY id DESC")
    fun getAllLogs(): Flow<List<StudyLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: StudyLog)

    @Query("SELECT SUM(durationMinutes) FROM study_logs")
    fun getTotalStudyMinutes(): Flow<Int?>
}
