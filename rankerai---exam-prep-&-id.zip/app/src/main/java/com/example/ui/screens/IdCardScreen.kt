package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocalPizza
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TargetExam
import com.example.ui.components.IdCardView
import com.example.ui.theme.*
import com.example.ui.viewmodel.RankerViewModel

@Composable
fun IdCardScreen(
    viewModel: RankerViewModel,
    onOpenPricing: () -> Unit
) {
    val context = LocalContext.current
    val userProfile by viewModel.userProfile.collectAsState()

    var showEditDialog by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf(userProfile.name) }
    var editExam by remember { mutableStateOf(userProfile.targetExam) }
    var editCollege by remember { mutableStateOf(userProfile.targetCollege) }
    var editPickupLine by remember { mutableStateOf(userProfile.pickupLine) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Official Student ID Card 🪪",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Generated with ${userProfile.targetExam.bgTitle} College Background",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                IconButton(
                    onClick = {
                        editName = userProfile.name
                        editExam = userProfile.targetExam
                        editCollege = userProfile.targetCollege
                        editPickupLine = userProfile.pickupLine
                        showEditDialog = true
                    },
                    colors = IconButtonDefaults.iconButtonColors(containerColor = PrimaryBlueVariant)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = Color.White)
                }
            }
        }

        item {
            // Interactive Student ID Card
            IdCardView(
                userProfile = userProfile,
                onPhotoSelected = { uri -> viewModel.setPhotoUri(uri) },
                onShareClick = {
                    val sendIntent = Intent().apply {
                        action = Intent.ACTION_SEND
                        putExtra(
                            Intent.EXTRA_TEXT,
                            "🎯 Check out my Official Student ID Card!\nName: ${userProfile.name}\nTarget Exam: ${userProfile.targetExam.title}\nTarget College: ${userProfile.targetCollege}\n\nPreparing for top ranks with RankerAI App! 🚀"
                        )
                        type = "text/plain"
                    }
                    val shareIntent = Intent.createChooser(sendIntent, "Share Student ID Card")
                    context.startActivity(shareIntent)
                }
            )
        }

        item {
            // Pro Subscription Offer Banner
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, AccentGold),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenPricing() }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocalPizza,
                            contentDescription = null,
                            tint = AccentGold,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Upgrade to Pro Ranker 🍕", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("Only ₹249 for 3 Months (Price of a Pizza!)", fontSize = 11.sp, color = AccentGold)
                        }
                    }

                    Button(
                        onClick = onOpenPricing,
                        colors = ButtonDefaults.buttonColors(containerColor = AccentGold, contentColor = Color.Black),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Get Pro", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Edit Profile Dialog
    if (showEditDialog) {
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text("Edit Student ID Details") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Student Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Select Exam Stream:", fontSize = 12.sp, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TargetExam.entries.forEach { exam ->
                            FilterChip(
                                selected = editExam == exam,
                                onClick = {
                                    editExam = exam
                                    editCollege = exam.defaultCollege
                                    editPickupLine = exam.defaultPickupLine
                                },
                                label = { Text("${exam.iconEmoji} ${exam.code}", fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = editCollege,
                        onValueChange = { editCollege = it },
                        label = { Text("Target College / Institute") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = editPickupLine,
                        onValueChange = { editPickupLine = it },
                        label = { Text("Motivational Quote / Tagline") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateUserProfile(
                            name = editName,
                            targetExam = editExam,
                            targetCollege = editCollege,
                            pickupLine = editPickupLine,
                            photoUri = null
                        )
                        showEditDialog = false
                        Toast.makeText(context, "ID Card Updated!", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Text("Save Changes")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
