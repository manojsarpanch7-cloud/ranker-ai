package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.QuizQuestion
import com.example.data.model.StudyLog
import com.example.data.model.StudyNote
import com.example.data.model.StudyTask
import com.example.data.model.TargetExam
import com.example.data.model.UserProfile
import com.example.data.remote.GeminiQuizService
import com.example.data.repository.StudyRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TimerState(
    val isRunning: Boolean = false,
    val secondsElapsed: Int = 0,
    val selectedSubject: String = "Physics"
)

data class QuizUiState(
    val isGenerating: Boolean = false,
    val questions: List<QuizQuestion> = emptyList(),
    val currentQuestionIndex: Int = 0,
    val selectedAnswers: Map<Int, Int> = emptyMap(),
    val isSubmitted: Boolean = false,
    val currentTopic: String = ""
)

class RankerViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val taskDao = db.taskDao()
    private val logDao = db.logDao()

    private val _userProfile = MutableStateFlow(
        UserProfile(
            name = "Kartiken",
            targetExam = TargetExam.NEET,
            targetCollege = "AIIMS New Delhi",
            pickupLine = "Future Doctor holding Stethoscope 🩺",
            photoUri = null,
            isPro = false,
            studentIdNumber = "RANKER-2026-NEET089"
        )
    )
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _showPlayStoreNotice = MutableStateFlow(true)
    val showPlayStoreNotice: StateFlow<Boolean> = _showPlayStoreNotice.asStateFlow()

    private val _showPricingModal = MutableStateFlow(false)
    val showPricingModal: StateFlow<Boolean> = _showPricingModal.asStateFlow()

    val tasksList: StateFlow<List<StudyTask>> = taskDao.getAllTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val studyLogs: StateFlow<List<StudyLog>> = logDao.getAllLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalMinutesFromDb: StateFlow<Int?> = logDao.getTotalMinutesLogged()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _selectedNoteSubject = MutableStateFlow("All")
    val selectedNoteSubject: StateFlow<String> = _selectedNoteSubject.asStateFlow()

    private val _quizUiState = MutableStateFlow(QuizUiState())
    val quizUiState: StateFlow<QuizUiState> = _quizUiState.asStateFlow()

    private val _timerState = MutableStateFlow(TimerState())
    val timerState: StateFlow<TimerState> = _timerState.asStateFlow()
    private var timerJob: Job? = null

    init {
        viewModelScope.launch {
            taskDao.getAllTasks().collect { currentTasks ->
                if (currentTasks.isEmpty()) {
                    val exam = _userProfile.value.targetExam
                    taskDao.insertTask(StudyTask(title = "Revise ${exam.subjects.first()} Notes & Formulas", subject = exam.subjects.first(), examCode = exam.code))
                    taskDao.insertTask(StudyTask(title = "Solve 20 PYQs from 2022-2023 papers", subject = exam.subjects.getOrElse(1) { exam.subjects.first() }, examCode = exam.code))
                    taskDao.insertTask(StudyTask(title = "Take 5-Question AI Practice Quiz", subject = "All", examCode = exam.code))
                }
            }
        }
    }

    fun dismissPlayStoreNotice() {
        _showPlayStoreNotice.value = false
    }

    fun openPricingModal() {
        _showPricingModal.value = true
    }

    fun closePricingModal() {
        _showPricingModal.value = false
    }

    fun updateUserProfile(
        name: String,
        targetExam: TargetExam,
        targetCollege: String,
        pickupLine: String,
        photoUri: String?
    ) {
        _userProfile.update {
            it.copy(
                name = name.ifBlank { "Kartiken" },
                targetExam = targetExam,
                targetCollege = targetCollege.ifBlank { targetExam.defaultCollege },
                pickupLine = pickupLine.ifBlank { targetExam.defaultPickupLine },
                photoUri = photoUri ?: it.photoUri
            )
        }
    }

    fun setPhotoUri(uriString: String) {
        _userProfile.update { it.copy(photoUri = uriString) }
    }

    fun activateProSubscription() {
        _userProfile.update { it.copy(isPro = true) }
        closePricingModal()
    }

    fun getNotes(): List<StudyNote> {
        val examNotes = StudyRepository.getNotesForExam(_userProfile.value.targetExam)
        return if (_selectedNoteSubject.value == "All") {
            examNotes
        } else {
            examNotes.filter { it.subject == _selectedNoteSubject.value }
        }
    }

    fun setNoteSubjectFilter(subject: String) {
        _selectedNoteSubject.value = subject
    }

    fun generateQuizForTopic(topic: String) {
        val exam = _userProfile.value.targetExam
        val finalTopic = topic.ifBlank { exam.subjects.first() }
        _quizUiState.update {
            QuizUiState(isGenerating = true, currentTopic = finalTopic)
        }
        viewModelScope.launch {
            val questions = GeminiQuizService.generateQuiz(finalTopic, exam)
            _quizUiState.update {
                it.copy(
                    isGenerating = false,
                    questions = questions,
                    currentQuestionIndex = 0,
                    selectedAnswers = emptyMap(),
                    isSubmitted = false
                )
            }
        }
    }

    fun selectAnswer(questionIndex: Int, optionIndex: Int) {
        if (_quizUiState.value.isSubmitted) return
        _quizUiState.update {
            val updatedMap = it.selectedAnswers.toMutableMap()
            updatedMap[questionIndex] = optionIndex
            it.copy(selectedAnswers = updatedMap)
        }
    }

    fun submitQuiz() {
        _quizUiState.update { it.copy(isSubmitted = true) }
    }

    fun nextQuizQuestion() {
        _quizUiState.update {
            if (it.currentQuestionIndex < it.questions.size - 1) {
                it.copy(currentQuestionIndex = it.currentQuestionIndex + 1)
            } else it
        }
    }

    fun previousQuizQuestion() {
        _quizUiState.update {
            if (it.currentQuestionIndex > 0) {
                it.copy(currentQuestionIndex = it.currentQuestionIndex - 1)
            } else it
        }
    }

    fun toggleTask(task: StudyTask) {
        viewModelScope.launch {
            taskDao.updateTask(task.copy(isCompleted = !task.isCompleted))
        }
    }

    fun addNewTask(title: String, subject: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            taskDao.insertTask(
                StudyTask(
                    title = title,
                    subject = subject,
                    examCode = _userProfile.value.targetExam.code
                )
            )
        }
    }

    fun deleteTask(task: StudyTask) {
        viewModelScope.launch {
            taskDao.deleteTask(task)
        }
    }

    fun setTimerSubject(subject: String) {
        _timerState.update { it.copy(selectedSubject = subject) }
    }

    fun startTimer() {
        if (_timerState.value.isRunning) return
        _timerState.update { it.copy(isRunning = true) }
        timerJob = viewModelScope.launch {
            while (_timerState.value.isRunning) {
                delay(1000)
                _timerState.update { it.copy(secondsElapsed = it.secondsElapsed + 1) }
            }
        }
    }

    fun pauseTimer() {
        _timerState.update { it.copy(isRunning = false) }
        timerJob?.cancel()
    }

    fun resetTimer() {
        pauseTimer()
        _timerState.update { it.copy(secondsElapsed = 0) }
    }

    fun saveTimerSession() {
        val seconds = _timerState.value.secondsElapsed
        if (seconds < 10) return
        val minutes = (seconds / 60).coerceAtLeast(1)
        val subject = _timerState.value.selectedSubject
        viewModelScope.launch {
            logDao.insertLog(StudyLog(subject = subject, minutesLogged = minutes))
            _userProfile.update { it.copy(totalStudyMinutes = it.totalStudyMinutes + minutes) }
            resetTimer()
        }
    }

    fun addManualStudyLog(subject: String, minutes: Int) {
        if (minutes <= 0) return
        viewModelScope.launch {
            logDao.insertLog(StudyLog(subject = subject, minutesLogged = minutes))
            _userProfile.update { it.copy(totalStudyMinutes = it.totalStudyMinutes + minutes) }
        }
    }
}
