package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.RankerViewModel

@Composable
fun TrackerScreen(
    viewModel: RankerViewModel
) {
    val context = LocalContext.current
    val userProfile by viewModel.userProfile.collectAsState()
    val timerState by viewModel.timerState.collectAsState()
    val studyLogs by viewModel.studyLogs.collectAsState()
    val totalMinutesFromDb by viewModel.totalMinutesFromDb.collectAsState()

    var showManualLogDialog by remember { mutableStateOf(false) }
    var manualSubjectInput by remember { mutableStateOf(userProfile.targetExam.subjects.first()) }
    var manualMinutesInput by remember { mutableStateOf("") }

    val formattedTimerTime = remember(timerState.secondsElapsed) {
        val hrs = timerState.secondsElapsed / 3600
        val mins = (timerState.secondsElapsed % 3600) / 60
        val secs = timerState.secondsElapsed % 60
        String.format("%02d:%02d:%02d", hrs, mins, secs)
    }

    val totalHoursDisplay = remember(userProfile.totalStudyMinutes, totalMinutesFromDb) {
        val totalMins = userProfile.totalStudyMinutes + (totalMinutesFromDb ?: 0)
        String.format("%.1f", totalMins / 60.0)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Header
            Column {
                Text(
                    text = "Study Hours & Progress Tracker ⏱️",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Track daily focus hours & maintain your study streak for ${userProfile.targetExam.title}",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }

        item {
            // Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Total Hours", fontSize = 11.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("$totalHoursDisplay hrs", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Whatshot, contentDescription = null, tint = AccentGold, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Current Streak", fontSize = 11.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("${userProfile.currentStreak} Days 🔥", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = AccentGold)
                    }
                }
            }
        }

        item {
            // Live Stopwatch Card
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("LIVE STUDY STOPWATCH", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PrimaryBlue)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = formattedTimerTime,
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Subject Selector
                    Text("Select Subject:", fontSize = 12.sp, color = TextSecondary)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(vertical = 6.dp)
                    ) {
                        userProfile.targetExam.subjects.forEach { subject ->
                            FilterChip(
                                selected = timerState.selectedSubject == subject,
                                onClick = { viewModel.setTimerSubject(subject) },
                                label = { Text(subject, fontSize = 11.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!timerState.isRunning) {
                            Button(
                                onClick = { viewModel.startTimer() },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Start Focus")
                            }
                        } else {
                            Button(
                                onClick = { viewModel.pauseTimer() },
                                colors = ButtonDefaults.buttonColors(containerColor = AccentGold, contentColor = Color.Black),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Pause, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Pause")
                            }
                        }

                        Button(
                            onClick = {
                                viewModel.saveTimerSession()
                                Toast.makeText(context, "Study Session Logged!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentEmerald, contentColor = Color.Black),
                            shape = RoundedCornerShape(12.dp),
                            enabled = timerState.secondsElapsed >= 10
                        ) {
                            Text("Save Session", fontWeight = FontWeight.Bold)
                        }

                        IconButton(
                            onClick = { viewModel.resetTimer() }
                        ) {
                            Icon(Icons.Default.RestartAlt, contentDescription = "Reset", tint = TextSecondary)
                        }
                    }
                }
            }
        }

        item {
            // Manual Log Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Recent Study Logs", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                TextButton(onClick = { showManualLogDialog = true }) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = PrimaryBlue)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Manual Log", fontSize = 12.sp, color = PrimaryBlue)
                }
            }
        }

        if (studyLogs.isEmpty()) {
            item {
                Text(
                    text = "No recorded sessions yet. Use the stopwatch above or add a manual log!",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        } else {
            items(studyLogs) { log ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(log.subject, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("Study Session", fontSize = 11.sp, color = TextSecondary)
                        }
                        Surface(
                            color = PrimaryBlue.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "+${log.minutesLogged} mins",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryBlue,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showManualLogDialog) {
        AlertDialog(
            onDismissRequest = { showManualLogDialog = false },
            title = { Text("Log Offline Study Hours") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select Subject:", fontSize = 12.sp, color = TextSecondary)
                    userProfile.targetExam.subjects.forEach { subj ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { manualSubjectInput = subj }
                        ) {
                            RadioButton(
                                selected = manualSubjectInput == subj,
                                onClick = { manualSubjectInput = subj }
                            )
                            Text(subj, fontSize = 13.sp, color = TextPrimary)
                        }
                    }

                    OutlinedTextField(
                        value = manualMinutesInput,
                        onValueChange = { manualMinutesInput = it },
                        label = { Text("Duration in Minutes") },
                        placeholder = { Text("e.g. 90") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val mins = manualMinutesInput.toIntOrNull() ?: 0
                        if (mins > 0) {
                            viewModel.addManualStudyLog(manualSubjectInput, mins)
                            Toast.makeText(context, "Logged $mins mins!", Toast.LENGTH_SHORT).show()
                        }
                        showManualLogDialog = false
                    }
                ) {
                    Text("Save Log")
                }
            },
            dismissButton = {
                TextButton(onClick = { showManualLogDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
