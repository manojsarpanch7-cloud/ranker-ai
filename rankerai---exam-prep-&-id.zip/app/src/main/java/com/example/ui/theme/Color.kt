package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryBlue = Color(0xFF3B82F6)
val PrimaryBlueVariant = Color(0xFF1D4ED8)
val SecondaryTeal = Color(0xFF14B8A6)
val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val AccentGold = Color(0xFFF59E0B)
val AccentEmerald = Color(0xFF10B981)
val AccentRose = Color(0xFFF43F5E)
val CardBorder = Color(0xFF334155)
