package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.MainViewModel
import com.example.ui.components.PlayStoreNoticeDialog
import com.example.ui.components.PricingBottomSheet
import com.example.ui.screens.AiQuizScreen
import com.example.ui.screens.DailyTasksScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ProgressTrackerScreen
import com.example.ui.screens.StudyMaterialsScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.RankerAiTheme
import com.example.ui.theme.TextSecondary

enum class ScreenTab(val title: String) {
    DASHBOARD("Home"),
    NOTES("Notes & PYQs"),
    QUIZ("AI Quiz"),
    TRACKER("Hours"),
    TASKS("Tasks")
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            RankerAiTheme {
                val showNotice by viewModel.showNoticeDialog.collectAsState()
                val showPricing by viewModel.showPricingSheet.collectAsState()

                var currentTab by remember { mutableStateOf(ScreenTab.DASHBOARD) }

                if (showNotice) {
                    PlayStoreNoticeDialog(
                        onDismiss = { viewModel.dismissNoticeDialog() }
                    )
                }

                if (showPricing) {
                    PricingBottomSheet(
                        onDismiss = { viewModel.togglePricingSheet(false) }
                    )
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(DarkBackground),
                    containerColor = DarkBackground,
                    bottomBar = {
                        NavigationBar(
                            containerColor = DarkSurface,
                            tonalElevation = 8.dp
                        ) {
                            val navItems = listOf(
                                ScreenTab.DASHBOARD to Icons.Default.Home,
                                ScreenTab.NOTES to Icons.Default.Book,
                                ScreenTab.QUIZ to Icons.Default.AutoAwesome,
                                ScreenTab.TRACKER to Icons.Default.Schedule,
                                ScreenTab.TASKS to Icons.Default.CheckCircle
                            )

                            navItems.forEach { (tab, icon) ->
                                val isSelected = currentTab == tab
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { currentTab = tab },
                                    icon = {
                                        Icon(
                                            imageVector = icon,
                                            contentDescription = tab.title,
                                            tint = if (isSelected) PrimaryBlue else TextSecondary
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = tab.title,
                                            color = if (isSelected) PrimaryBlue else TextSecondary,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        indicatorColor = PrimaryBlue.copy(alpha = 0.2f)
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            ScreenTab.DASHBOARD -> DashboardScreen(
                                viewModel = viewModel,
                                onNavigateToQuiz = { topic ->
                                    viewModel.generateQuizForTopic(topic)
                                    currentTab = ScreenTab.QUIZ
                                },
                                onNavigateToNotes = { currentTab = ScreenTab.NOTES },
                                onNavigateToTasks = { currentTab = ScreenTab.TASKS },
                                onNavigateToProgress = { currentTab = ScreenTab.TRACKER }
                            )
                            ScreenTab.NOTES -> StudyMaterialsScreen(
                                viewModel = viewModel,
                                onStartQuizForTopic = { topic ->
                                    viewModel.generateQuizForTopic(topic)
                                    currentTab = ScreenTab.QUIZ
                                }
                            )
                            ScreenTab.QUIZ -> AiQuizScreen(
                                viewModel = viewModel
                            )
                            ScreenTab.TRACKER -> ProgressTrackerScreen(
                                viewModel = viewModel
                            )
                            ScreenTab.TASKS -> DailyTasksScreen(
                                viewModel = viewModel
                            )
                        }
                    }
                }
            }
        }
    }
}
