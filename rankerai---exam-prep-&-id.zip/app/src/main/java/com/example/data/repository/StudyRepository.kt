package com.example.data.repository

import com.example.data.local.LogDao
import com.example.data.local.TaskDao
import com.example.data.model.PyqItem
import com.example.data.model.QuizQuestion
import com.example.data.model.StudyLog
import com.example.data.model.StudyNote
import com.example.data.model.StudyTask
import com.example.data.model.TargetExam
import com.example.data.remote.GeminiQuizService
import kotlinx.coroutines.flow.Flow

class StudyRepository(
    private val taskDao: TaskDao,
    private val logDao: LogDao,
    private val geminiQuizService: GeminiQuizService = GeminiQuizService()
) {

    fun getAllTasks(): Flow<List<StudyTask>> = taskDao.getAllTasks()

    suspend fun insertTask(task: StudyTask) = taskDao.insertTask(task)

    suspend fun updateTask(task: StudyTask) = taskDao.updateTask(task)

    suspend fun deleteTask(task: StudyTask) = taskDao.deleteTask(task)

    fun getAllLogs(): Flow<List<StudyLog>> = logDao.getAllLogs()

    suspend fun insertLog(log: StudyLog) = logDao.insertLog(log)

    suspend fun getQuizForTopic(targetExam: TargetExam, topic: String): List<QuizQuestion> {
        val remoteQuiz = geminiQuizService.generateQuizForTopic(targetExam, topic)
        if (remoteQuiz.isNotEmpty()) {
            return remoteQuiz
        }
        return generateFallbackQuiz(targetExam, topic)
    }

    private fun generateFallbackQuiz(targetExam: TargetExam, topic: String): List<QuizQuestion> {
        return when (targetExam) {
            TargetExam.NEET -> listOf(
                QuizQuestion(
                    id = "q1",
                    questionText = "Which phase of mitosis involves alignment of chromosomes along the equatorial plate?",
                    options = listOf("Prophase", "Metaphase", "Anaphase", "Telophase"),
                    correctAnswerIndex = 1,
                    explanation = "During Metaphase, spindle fibers attach to kinetochores of chromosomes and align them at the metaphase plate."
                ),
                QuizQuestion(
                    id = "q2",
                    questionText = "What is the oxygen carrier protein in human erythrocytes?",
                    options = listOf("Myoglobin", "Hemoglobin", "Albumin", "Globulin"),
                    correctAnswerIndex = 1,
                    explanation = "Hemoglobin is a tetrameric protein containing heme groups that reversibly bind oxygen."
                ),
                QuizQuestion(
                    id = "q3",
                    questionText = "Which hormone stimulates water reabsorption in the distal convoluted tubule and collecting duct?",
                    options = listOf("Aldosterone", "ADH (Vasopressin)", "Renin", "ANP"),
                    correctAnswerIndex = 1,
                    explanation = "ADH inserts aquaporin-2 channels into apical membranes of collecting duct principal cells."
                )
            )
            TargetExam.JEE -> listOf(
                QuizQuestion(
                    id = "q4",
                    questionText = "What is the moment of inertia of a uniform solid sphere of mass M and radius R about its diameter?",
                    options = listOf("1/2 M R²", "2/5 M R²", "2/3 M R²", "7/5 M R²"),
                    correctAnswerIndex = 1,
                    explanation = "I = (2/5) M R² for a uniform solid sphere passing through its center of mass."
                ),
                QuizQuestion(
                    id = "q5",
                    questionText = "What is the hybridization of sulphur in SF6 molecule?",
                    options = listOf("sp3", "sp3d", "sp3d2", "sp3d3"),
                    correctAnswerIndex = 2,
                    explanation = "Sulphur forms 6 bond pairs with fluorine using sp3d2 hybrid orbitals resulting in octahedral geometry."
                ),
                QuizQuestion(
                    id = "q6",
                    questionText = "The work done in expanding a gas isothermally depends on:",
                    options = listOf("Temperature only", "Pressure ratio only", "Initial and final volume ratio and temperature", "Heat capacity"),
                    correctAnswerIndex = 2,
                    explanation = "W = n R T ln(V2/V1), showing dependence on both temperature T and volume ratio V2/V1."
                )
            )
            TargetExam.UPSC -> listOf(
                QuizQuestion(
                    id = "q7",
                    questionText = "Which article of the Constitution of India guarantees the Right to Equality before Law?",
                    options = listOf("Article 14", "Article 19", "Article 21", "Article 32"),
                    correctAnswerIndex = 0,
                    explanation = "Article 14 states that the State shall not deny to any person equality before the law or equal protection of the laws."
                ),
                QuizQuestion(
                    id = "q8",
                    questionText = "The Western Ghats in Maharashtra and Goa are locally known as:",
                    options = listOf("Sahyadri", "Nilgiri", "Anaimalai", "Cardamom Hills"),
                    correctAnswerIndex = 0,
                    explanation = "The Western Ghats are known as Sahyadri in Maharashtra and Karnataka."
                )
            )
            TargetExam.CA -> listOf(
                QuizQuestion(
                    id = "q9",
                    questionText = "Which Accounting Standard in India deals with Accounting for Property, Plant and Equipment?",
                    options = listOf("AS-2", "AS-10 (Ind AS 16)", "AS-16", "AS-22"),
                    correctAnswerIndex = 1,
                    explanation = "AS-10 / Ind AS 16 prescribes accounting treatment for Property, Plant and Equipment (PPE)."
                ),
                QuizQuestion(
                    id = "q10",
                    questionText = "Under GST law, input tax credit is NOT available on:",
                    options = listOf("Capital goods for business", "Motor vehicles for passenger transport (<13 seats)", "Raw materials for production", "Packing material"),
                    correctAnswerIndex = 1,
                    explanation = "Under Section 17(5) of CGST Act, ITC on motor vehicles with seating capacity up to 13 persons is blocked."
                )
            )
            TargetExam.BOARDS -> listOf(
                QuizQuestion(
                    id = "q11",
                    questionText = "Which law states that current density is directly proportional to electric field intensity?",
                    options = listOf("Ohm's Law in vector form (J = σE)", "Gauss Law", "Ampere Law", "Faraday Law"),
                    correctAnswerIndex = 0,
                    explanation = "Microscopic form of Ohm's law is J = σ E."
                )
            )
        }
    }

    companion object {
        fun getNotesForExam(targetExam: TargetExam): List<StudyNote> {
            return when (targetExam) {
                TargetExam.NEET -> listOf(
                    StudyNote(
                        id = "note1",
                        examCode = targetExam.code,
                        subject = "Biology",
                        chapterTitle = "Human Physiology & Circulation",
                        keyPoints = listOf(
                            "Sinoatrial node (SA Node) acts as the primary pacemaker generating 70-75 action potentials/min.",
                            "Double Circulation consists of Pulmonary Circuit (Right Ventricle to Lungs to Left Atrium) and Systemic Circuit.",
                            "Cardiac Output = Stroke Volume (70mL) x Heart Rate (72 bpm) ≈ 5 Liters/min."
                        ),
                        highYieldFormulas = listOf("CO = SV x HR", "Mean Arterial Pressure = Diastolic + 1/3 Pulse Pressure"),
                        pyqs = listOf(
                            PyqItem(
                                id = "pyq101",
                                year = "NEET 2023",
                                questionText = "Which cell of the organ of Corti acts as auditory receptors?",
                                options = listOf("Hair cells", "Deiters cells", "Hensen cells", "Pillar cells"),
                                correctAnswerIndex = 0,
                                stepByStepSolution = "Internal ear contains organ of Corti located on basilar membrane. Hair cells are microvilli sensory receptors for hearing."
                            ),
                            PyqItem(
                                id = "pyq102",
                                year = "NEET 2022",
                                questionText = "Identify the correct order of blood clot formation cascade:",
                                options = listOf(
                                    "Thromboplastin -> Prothrombinase -> Thrombin -> Fibrinogen -> Fibrin",
                                    "Fibrin -> Thrombin -> Prothrombin",
                                    "Thrombin -> Fibrinogen -> Thromboplastin",
                                    "Prothrombin -> Fibrinogen -> Thrombin"
                                ),
                                correctAnswerIndex = 0,
                                stepByStepSolution = "Injured tissue releases thromboplastin forming prothrombinase enzyme complex which converts inactive prothrombin to active thrombin."
                            )
                        )
                    ),
                    StudyNote(
                        id = "note2",
                        examCode = targetExam.code,
                        subject = "Physics",
                        chapterTitle = "Ray Optics & Optical Instruments",
                        keyPoints = listOf(
                            "Total Internal Reflection occurs when light travels from denser to rarer medium with angle of incidence i > ic.",
                            "Critical Angle formula: sin(ic) = n2 / n1.",
                            "Lens Maker's Formula: 1/f = (n - 1) [1/R1 - 1/R2]."
                        ),
                        highYieldFormulas = listOf("1/f = 1/v - 1/u", "P = 1/f (in meters) = P1 + P2"),
                        pyqs = listOf(
                            PyqItem(
                                id = "pyq103",
                                year = "NEET 2023",
                                questionText = "A convex lens of focal length 20 cm is placed in contact with a concave lens of focal length 40 cm. The power of combination is:",
                                options = listOf("+2.5 D", "+5.0 D", "-2.5 D", "+1.25 D"),
                                correctAnswerIndex = 0,
                                stepByStepSolution = "P1 = +100/20 = +5D. P2 = -100/40 = -2.5D. P_total = 5 - 2.5 = +2.5 D."
                            )
                        )
                    )
                )
                TargetExam.JEE -> listOf(
                    StudyNote(
                        id = "note3",
                        examCode = targetExam.code,
                        subject = "Physics",
                        chapterTitle = "Rotational Motion & Dynamics",
                        keyPoints = listOf(
                            "Torque τ = I α = r x F.",
                            "Angular Momentum L = I ω. Conserved when net external torque is zero.",
                            "Parallel Axis Theorem: I = I_cm + M d²."
                        ),
                        highYieldFormulas = listOf("I = I_cm + M d²", "K_total = 1/2 M v² + 1/2 I ω²"),
                        pyqs = listOf(
                            PyqItem(
                                id = "pyq201",
                                year = "JEE Main 2023",
                                questionText = "A solid cylinder of mass 2 kg and radius 0.2 m rolls without slipping down an inclined plane of 30°. Its acceleration is:",
                                options = listOf("3.27 m/s²", "5.0 m/s²", "9.8 m/s²", "2.45 m/s²"),
                                correctAnswerIndex = 0,
                                stepByStepSolution = "For rolling without slipping: a = (g sin θ) / (1 + I / (M R²)). For solid cylinder I/(M R²) = 1/2. Thus a = (g sin 30) / (1.5) = (9.8 * 0.5) / 1.5 = 3.27 m/s²."
                            )
                        )
                    )
                )
                else -> listOf(
                    StudyNote(
                        id = "note4",
                        examCode = targetExam.code,
                        subject = "General Studies",
                        chapterTitle = "Indian Constitution & Governance",
                        keyPoints = listOf(
                            "Fundamental Rights contained in Part III (Articles 12 to 35).",
                            "Basic Structure Doctrine propounded in Kesavananda Bharati case (1973)."
                        ),
                        highYieldFormulas = listOf("Article 32: Constitutional Remedies", "Article 21: Life and Personal Liberty"),
                        pyqs = listOf(
                            PyqItem(
                                id = "pyq301",
                                year = "UPSC CSE 2022",
                                questionText = "Which one of the following categories of Fundamental Rights incorporates protection against untouchability?",
                                options = listOf("Right against Exploitation", "Right to Freedom", "Right to Constitutional Remedies", "Right to Equality"),
                                correctAnswerIndex = 3,
                                stepByStepSolution = "Article 17 under Right to Equality (Articles 14-18) abolishes untouchability and forbids its practice."
                            )
                        )
                    )
                )
            }
        }
    }
}
